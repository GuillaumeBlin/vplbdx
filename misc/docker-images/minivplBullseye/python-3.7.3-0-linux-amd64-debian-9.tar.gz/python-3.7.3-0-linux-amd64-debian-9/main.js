'use strict';

const path = require('path');

$app.postInstallation = function() {
  $app.debug(`Adding ${$app.name} to bitnami environment`);
  $app.writeSetenv({binPaths: [path.join($app.installdir, 'bin')]});
};
